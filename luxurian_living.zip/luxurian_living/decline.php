<?php
$id = $_REQUEST["id"];
include("config.php");
$q = "UPDATE `book_ride`set `booking_status`='Declined' where `id`='$id'";
$res = mysqli_query($conn,$q);
if($res>0)
{
    echo "<script>window.location.assign('view_booking.php?msg=Booking Declined')</script>";
}
else{
    echo mysqli_error($conn);
    die();
    echo "<script>window.location.assign('view_booking.php?msg=Try Again')</script>";
}
?>