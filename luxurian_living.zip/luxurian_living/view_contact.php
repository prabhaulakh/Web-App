<?php
 include_once("header.php");
 if($_SESSION["email"])
{
 //store
 $email = $_SESSION["email"];
}
else{
 echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
}
 ?>
   
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Contacts</h1>
                </div>
            </div>
          
        </div>
    </div>
</div>
<!-- End Hero Section -->
  		<div class="untree_co-section before-footer-section">
            <div class="container">
              <div class="row mb-5">
                <form class="col-md-12" method="post">
                  <div class="site-blocks-table">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
               <table class="table">
                    <tr>
                      <th>Sno</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Message</th>
                  </tr>
                  <?php
                  $sno = 1;
                  include("config.php");
                  $q = "SELECT * FROM `contact`";
                  $result = mysqli_query($conn,$q);
                  while($data = mysqli_fetch_array($result))
                  {
                  ?>
                  <tr>
                      <td><?php echo $sno;?></td>
                      <td><?php echo $data['name'];?></td>
                      <td><?php echo $data['email'];?></td>
                      <td><?php echo $data['contact'];?></td>
                      <td><?php echo $data['message'];?></td>
                  </tr>
                  <?php
                    $sno++;
                  }
                  ?>
              </table>   
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>