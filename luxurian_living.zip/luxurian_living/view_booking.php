<?php
include("header.php");
if($_SESSION["email"])
{
 //store
 $email = $_SESSION["email"];
}
else{
 echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
}
?>
  <!-- Page Header Start -->
  <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-1.jpg);">
      <div class="container-fluid page-header-inner py-5">
          <div class="container text-center">
              <h1 class="display-3 text-white mb-3 animated slideInDown">View Ride Bookings</h1>
          </div>
      </div>
  </div>
  <!-- Page Header End -->
  <!-- contact section -->
  <section class="contact_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
            <div class="row ">
              <div class="col-md-6">
                <!-- <h2>
                  View Orders
                </h2> -->
              </div>
             
            </div>
                <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                  <table class="table table-hover table-striped">
                    <tr class="table-dark">
                        <th>Sno</th>
                        <th>Brand</th>
                        <th>Car</th>
                        <th>User</th>
                        <th>Booking Date</th>
                        <th>Description</th>
                        <th>Booking Status</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    $sno = 1;
                    include("config.php");
                    $q = "SELECT book_ride.*, brand.brand_name, car.car_model, car.year FROM `book_ride` INNER JOIN `brand` on `brand`.`id`=`book_ride`.`brand` INNER JOIN `car` on `car`.`id`=`book_ride`.`car`";
                    $result = mysqli_query($conn,$q);
                    while($data = mysqli_fetch_array($result))
                    {
                        //print_r($data);
                    ?>
                    <tr>
                      <td><?php echo $sno;?></td>
                      <td><?php echo $data['brand_name'];?></td>
                      <td><?php echo $data['car_model']."-".$data['year'];?></td>
                      <td><?php echo $data['user'];?></td>
                      <td>Rs.<?php echo $data['ride_date'];?></td>
                      <td><?php echo $data['other_description'];?></td>
                      <td><?php echo $data['booking_status'];?></td>
                      <td>
                        <?php
                          if($data["booking_status"] == "Pending")
                          {
                        ?>
                          <a href="approve.php?id=<?php echo $data['id']; ?>"><i class="fa fa-check text-success"></i></a>
                          <a href="decline.php?id=<?php echo $data['id']; ?>"><i class="fa fa-times text-danger"></i></a>
                        <?php
                          }
                        ?>
                      </td>
                    </tr>
                    <?php
                    $sno++;
                    }
                    ?>
                </table>   
        </div>
      </div>
    </div>
  </section>
  <!-- end contact section -->
  <?php
include("footer.php");
?>
<?php
if(isset($_REQUEST["submit"]))
{
    $product_name = $_REQUEST["product_name"];
    include("connection.php");
    $q = "INSERT INTO `add_product`(`product_name`) VALUES ('$product_name')";
    $result = mysqli_query($conn,$q);
    if($result>0)
    {
        //url redirect
        echo "<script>window.location.assign('add_product.php?msg=Record Inserted')</script>";
    }
    else 
    {
        //url redirect
        //echo mysqli_error($conn);
        //die();
        echo "<script>window.location.assign('add_product.php?msg=Try Again')</script>";
    }
}
?>
 