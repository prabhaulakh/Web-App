<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Orders</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                    <!-- <img src="images/couch.png" class="img-fluid"> -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <table class="table table-bordered">
					<tr class="table-dark">
						<th>#</th> 
						<th>Order Id</th> 
						<th>User Name</th> 
						<th>User Email</th> 
						<th>Order Date</th> 
						<th>Order Status</th> 
						<th>View</th> 
					</tr>
					<?php
					include("config.php");
					$count=1;
					$query="SELECT * FROM `orders` WHERE email ='$_SESSION[user_email]'";
					$res=mysqli_query($conn,$query);
					while($row=mysqli_fetch_array($res))
					{
						echo"<tr>";
						echo"<td>".$count."</td>";
						echo"<td>".$row["order_id"]."</td>";
						echo"<td>".$row["user_name"]."</td>";
						echo"<td>".$row["email"]."</td>";
						echo"<td>".$row["order_date"]."</td>";
						echo"<td>".$row["status"]."</td>";
						echo "<td><a href='order_details.php?order_id=".$row['order_id']."'><i class='fa fa-eye'></i></a></td>";
						$count++;
						echo"</tr>";
					}
					?>
				</table>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?>