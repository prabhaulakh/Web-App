<?php
$id = $_REQUEST["id"];
include("config.php");
$q = "DELETE FROM `product` WHERE id='$id'";
$result = mysqli_query($conn,$q);
if($result>0)
{
    echo "<script>window.location.assign('manage_product.php?msg=Record Deleted')</script>";
}
else
{
    echo "<script>window.location.assign('manage_product.php?msg=Try Again')</script>";
}
?>