<?php
include_once "header.php";
?>
<!-- Start Hero Section -->
<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>About Us</h1>
								<p class="mb-4">
								At At Luxurian Living, we believe that furniture goes beyond being mere functional pieces; it is an expression of your style, a reflection of your personality, and a crucial element in creating a space that feels like home. Our mission is to provide you with a curated selection of high-quality, stylish, 
								and affordable furniture that transforms your living spaces into a haven of comfort and beauty.
								<p><a href="category.php" class="btn btn-secondary me-2">Shop Now</a></p></p>
								
							</div>
						</div>
						<div class="col-lg-7">
							<div class="hero-img-wrap">
								<img src="images/couch.png" class="img-fluid">
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->



		<!-- Start Why Choose Us Section -->
		<div class="why-choose-section">
			<div class="container">
				<div class="row justify-content-between align-items-center">
					<div class="col-lg-6">
						<h2 class="section-title">Why Choose Us</h2>
						<p>At Luxurian Living
, we understand that choosing the right furniture is not just about filling a space – it's about creating an environment that speaks to your style, enhances your comfort, and complements your lifestyle. 
								Here are some compelling reasons why you should choose us for all your furniture needs:</p>

						<div class="row my-5">
							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/truck.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Fast &amp; Free Shipping</h3>
									<p>Say goodbye to unexpected shipping fees. At Luxurian Living
, we believe that the price you see should be the price you pay. That's why we offer Free Shipping on all orders, 
									regardless of size or value. No hidden costs – just straightforward and transparent pricing.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/bag.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Easy to Shop</h3>
									<p>
									we believe that shopping for furniture should be a joy, not a chore. That's why we've designed our platform to make the entire process Easy to Shop, ensuring a seamless and enjoyable 
									experience for every customer. 
									 </p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/support.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>24/7 Support</h3>
									<p>we understand that questions and concerns don't adhere to regular business hours. That's why we're proud to offer 24/7 Support, 
									ensuring that assistance is just a message or call away, whenever you need it.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/return.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Hassle Free Returns</h3>
									<p>we understand that sometimes preferences may change, and we want you to feel confident in your furniture choices. That's why we've implemented a Hassle-Free Returns policy, 
									ensuring that the process is straightforward and stress-free.</p>
								</div>
							</div>

						</div>
					</div>

					<div class="col-lg-5">
						<div class="img-wrap">
							<img src="images/why-choose-us-img.jpg" alt="Image" class="img-fluid">
						</div>
					</div>

				</div>
			</div>
		</div>
		

		
<?php
include_once "footer.php";
?>