<?php
$conn = mysqli_connect("localhost","root","","luxurian_living");
//if connection not established
if(!$conn)
{
    //error msg print
    echo mysqli_error($conn);
}
?>