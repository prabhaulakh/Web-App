<?php
 include_once("header.php");
 if($_SESSION["email"])
{
 //store
 $email = $_SESSION["email"];
}
else{
 echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
}
 ?>
   
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Manage Product</h1>
                </div>
            </div>
           
        </div>
    </div>
</div>
<!-- End Hero Section -->
		<div class="untree_co-section before-footer-section">
            <div class="container">
              <div class="row mb-5">
                <form class="col-md-12" method="post">
                  <div class="site-blocks-table">
				   <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                    <table class="table">
                      <thead>
                        <tr>
						 <th class="product-price">S.no</th>
						  <th class="product-name">Category</th>
                          <th class="product-thumbnail">Image</th>
                          <th class="product-name">Product</th>
                          <th class="product-price">Price</th>
                          <th class="product-quantity">Qnty.</th>
						  <th class="product-price">Description</th>
                          <th class="product-total">Total</th>
                          <th class="product-remove">Remove</th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php
                        $sno = 1;
                        include("config.php");
                        $q = "SELECT `product`.*,`category`.`category_name` from `product` inner join `category` on `product`.`category`=`category`.`id`";
                        $result = mysqli_query($conn,$q);
                        while($data = mysqli_fetch_array($result)){
                            // print_r($data);
                    ?>
                        <tr>
						<td><?php echo $sno; ?></td>
						 <td><?php echo $data['category_name'];?></td>
                          <td class="product-thumbnail">
                            <img src="products/<?php echo $data['image'];?>" alt="Image" class="img-fluid">
                          </td>
                          <td class="product-name">
                            <h2 class="h5 text-black"><?php echo $data['product_name'];?></h2>
                          </td>
                          <td>&#163;<?php echo $data['price'];?></td>
                           <td><?php echo $data['quantity'];?></td>
                          <td><?php echo $data['description'];?></td>
						   <td>
                            <a href="update_product.php?id=<?php echo $data['id'];?>">
                                <i class="fa fa-edit fa-2x text-success"></i>
                            </a>
                        </td>
                          <td><a href="delete_product.php?id=<?php echo $data['id'];?>" class="btn btn-black btn-sm">X</a></td>
                        </tr>
        
                     
                      </tbody>
					    <?php
                    $sno++;
                        }
                    ?>
                    </table>
                  </div>
                </form>
              </div>
        <div class="row mb-5">
                    <div class="col-md-6 mb-3 mb-md-0">
                      </div>
                    <div class="col-md-6">
                      <a href="add_product.php"><button class="btn btn-outline-black btn-sm btn-block">Add More </button></a>
                    </div>
                  </div>
   
            </div>
          </div>
		



<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>