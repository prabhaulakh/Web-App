<style>
#quick{
	margin-top:-54px;
}

</style>
		<!-- Start Footer Section -->
		<footer class="footer-section">
			<div class="container relative">

				<div class="sofa-img">
					<img src="images/sofa.png" alt="Image" class="img-fluid">
				</div>

			

				<div class="row g-5 mb-5">
					<div class="col-lg-5">
						<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Luxurian <span>Living</span></a></div>
						<p class="mb-4">At Luxurian Living, we believe that furniture goes beyond being mere functional pieces; it is an expression of your style, a reflection of your personality, and a crucial element in creating a space that feels like home. Our mission is to provide you with a curated selection of high-quality, stylish, and affordable furniture that transforms your 
						living spaces into a haven of comfort and beauty.</p>

						<ul class="list-unstyled custom-social">
							<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
						</ul>
					</div>

					<div class="col-lg-7">
						<div class="row links-wrap" >
						<label class="text-black h4" id="quick">Quick Links </label>
							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="about.php">About us</a></li>
									<li><a href="services.php">Services</a></li>
									<li><a href="category.php">Shop</a></li>
									<li><a href="contact.php">Contact us</a></li>
								</ul>
							</div>
					

							<div class="col-6 col-sm-6 col-md-3">
							
								<ul class="list-unstyled">
									<li><a href="#">Best Seller </a></li>
									<li><a href="user_login.php">Login</a></li>
									<li><a href="user_register.php">Sign Up</a></li>
									<li><a href="login.php">Administrator</a></li>
								</ul>
							</div>

						</div>
					</div>

				</div>

				<div class="border-top copyright">
					<div class="row pt-4">
						<div class="col-lg-6">
			
						</div>

						<div class="col-lg-6 text-center text-lg-end">
							<ul class="list-unstyled d-inline-flex ms-auto">
								
								<li>Copyright &copy;. All Rights Reserved.</li>
							</ul>
						</div>

					</div>
				</div>

			</div>
		</footer>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
