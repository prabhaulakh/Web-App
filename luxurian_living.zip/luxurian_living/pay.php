<?php
include("header.php");
if($_SESSION["user_email"])
{
//store
$user_email = $_SESSION["user_email"];
}
else{
echo "<script>window.location.assign('user_login.php?msg=Unauthorised user')</script>";
}
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Shipping Details & Payment</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                    <img src="images/couch.png" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
               <form id="request" class="main_form" method="post" >
                     <div class="row">
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="User Name" type="text" name="user_name" required> 
                        </div>
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Email" type="email" name="email" value="<?php echo $_SESSION['user_email']; ?>" readonly> 
                        </div>
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Shipping Address" type="text" name="shipping_address"> 
                        </div>
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="City" type="text" name="city"> 
                        </div>
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="State" type="text" name="state"> 
                        </div>
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Card Holder Name" type="text"> 
                        </div>                       
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="CVV" type="text"> 
                        </div>                       
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Expiry Date" type="text"> 
                        </div>                       
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Pincode" name="pincode" type="number"> 
                        </div>                       
                        <div class="col-md-6 mt-4">
                           <input class="form-control" placeholder="Shipping Contact" name="shipping_contact" type="number"> 
                        </div>                       
                        <div class="col-md-12 mt-4">
                           <button type="submit" name="submit" class="btn btn-primary send_btn mx-auto">Submit</button>
                        </div>
                     </div>
                  </form>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?>
<?php
if(isset($_REQUEST["submit"]))
{
   $username = $_REQUEST['user_name'];
	$email = $_REQUEST['email'];
	$amount = $_SESSION['total'];
	$payment_mode = "Online";
	$order_date = date('d/m/Y');
	$shipping_address = $_REQUEST['shipping_address'];
	$shipping_contact = $_REQUEST['shipping_contact'];
	$city = $_REQUEST['city'];
	$state = $_REQUEST['state'];
	$pincode = $_REQUEST['pincode'];
	$order_id = rand();

	include('config.php');
	$order_qry = mysqli_query($conn,"INSERT INTO `orders`(`order_id`,`user_name`, `shipping_address`, `city`, `state`, `pincode`, `shipping_contact`, `email`, `amount`, `payment_mode`, `order_date`, `status`) VALUES ('$order_id','$username','$shipping_address','$city','$state','$pincode','$shipping_contact','$email','$amount','$payment_mode','$order_date','Pending')");

	$t =0;
	$total=0;
	if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0) {
	foreach($_SESSION['cart'] as $id=>$quantity){
	$t++;
	include 'config.php';
	$res  = mysqli_query($conn,"select * from product where `id`='$id'");
		if($row=mysqli_fetch_array($res))
			{
				// echo "<br><br><br><br>";
				// print_r($row);
				// echo $quantity;
				$order_Det = mysqli_query($conn,"INSERT INTO `order_details`(`order_id`, `product`, `quantity`, `amount`) VALUES ('$order_id','$row[id]','$quantity','$row[price]')");
			}
		}
	}

	if($order_qry)
	{
		unset($_SESSION['cart']);
		unset($_SESSION['total']);
		echo"<script>window.location.assign('orders.php?msg=Order Booked')</script>";
	}
	else
	{
		echo"<script>window.location.assign('orders.php?msg=try again')</script>";
	}
}
?>
