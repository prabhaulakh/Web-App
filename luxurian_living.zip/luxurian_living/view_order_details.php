<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Order Details</h1>
                </div>
            </div>
           
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section before-footer-section">
            <div class="container">
              <div class="row mb-5">
                <form class="col-md-12" method="post">
                  <div class="site-blocks-table">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
				<table class="table">
					<?php
					include("config.php");
					$query="SELECT * FROM `orders` WHERE order_id='$_REQUEST[order_id]'";
					$res=mysqli_query($conn,$query);
					if($row=mysqli_fetch_array($res))
					{
					?>
						<tr>
							<th>Order ID</th>
							<td><?php echo $row['order_id']; ?></td>
						</tr>
						<tr>
							<th>User Name</th>
							<td><?php echo $row['user_name']; ?></td>
						</tr>
						<tr>
							<th>Email</th>
							<td><?php echo $row['email']; ?></td>
						</tr>
						<tr>
							<th>Order Status</th>
							<td><?php echo $row['status']; ?></td>
						</tr>
						<tr>
							<th>Grand Total</th>
							<td>&#163;<?php echo $row['amount']; ?></td>
						</tr>
						<tr>
							<th>Order Date</th>
							<td><?php echo $row['order_date']; ?></td>
						</tr>
						<tr>
							<th>Shipping Address</th>
							<td><?php echo $row['shipping_address']; ?></td>
						</tr>
						<tr>
							<th>City & State (Pincode)</th>
							<td><?php echo $row['city']." ".$row['state']." ".$row['pincode']; ?></td>
						</tr>
					<?php
					}
					?>
				</table>
				<h1>Product Details</h1>
				<hr>
				<table class="table">
					<tr class="table-dark">
						<th class="product-name">S.no</th>
						<th class="product-name">Product</th>
						<th class="product-name">Quantity</th>
						<th class="product-name">Price Per Piece</th>
						<th class="product-name">Total Price <small>(as per item)</small></th>
					</tr>
					<?php
					$cnt =1;
					include("config.php");
					$querys="SELECT order_details.*,product.product_name FROM `order_details` inner join product on product.id=order_details.product WHERE order_details.order_id='$_REQUEST[order_id]'";
					$ress=mysqli_query($conn,$querys);
					while($rowss=mysqli_fetch_array($ress))
					{
					?>
						<tr>
							<th><?php echo $cnt; ?></th>
							<th><?php echo $rowss['product_name']; ?></th>
							<th><?php echo $rowss['quantity']; ?></th>
							<th>&#163;<?php echo $rowss['amount']; ?></th>
							<th>&#163;<?php echo $rowss['amount']*$rowss['quantity']; ?></th>
						</tr>
					<?php
					$cnt++;
					}
					?>
				</table>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>