<?php
    include_once("header.php");
?>

		<!-- Start Hero Section -->
        <div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>Furniture</h1>
							</div>
						</div>
						<div class="col-lg-7">
							
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		

		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">
                  <?php
                    $sno = 1;
                    include("config.php");
                    $q = "SELECT `product`.*,`category`.`category_name`,`category`.`id` as `category_id` from `product` inner join `category` on `product`.`category`=`category`.`id` where `product`.`category`='$_REQUEST[id]'";
                    $result = mysqli_query($conn,$q);
                    while($data = mysqli_fetch_array($result)){
                    ?>
		      		<!-- Start Column 1 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5">
						<a class="product-item" href="addtocart.php?x=<?php echo $data['id']?>">
							<img src="products/<?php echo $data['image'];?>" class="img-fluid product-thumbnail">
							<h3 class="product-title"><?php echo $data['product_name']."(".$data['quantity'].")";?></h3>
							<strong class="product-price">&#163;<?php echo $data['price']; ?></strong>
							
                            <span class="icon-cross">
								<img src="images/cross.svg" class="img-fluid">
							</span>
                        </a>
						
                            
							
							
					</div> 
					<!-- End Column 1 -->
					<?php
                    }
                    ?>
		      	</div>
		    </div>
		</div>

<?php
include_once("footer.php");
?>