<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Administrator</h1>
                </div>
            </div>
           
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <form method="post">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                            </div>
                        </div>                    
                        <div class="col-12">
                            <button name="submit" class="btn btn-primary w-100 py-3" type="submit">Login</button>
                        </div>
                    </div>
                </form>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?>
<?php
if(isset($_REQUEST["submit"]))
{
   $email = $_REQUEST["email"];
   $password = $_REQUEST["password"];
   include("config.php");
    $q = "SELECT * from admin_login where email='$email' and password='$password'";
    $result = mysqli_query($conn,$q);
    if($data = mysqli_fetch_array($result))
    {
        //create
        $_SESSION['email']=$email;
        //url redirect
        echo "<script>window.location.assign('dashboard.php')</script>";
    }
    else{
        //url redirect
        echo mysqli_error($conn);
        die();
        echo "<script>window.location.assign('login.php?msg=Invalid email or password')</script>";
   }
}
?>
