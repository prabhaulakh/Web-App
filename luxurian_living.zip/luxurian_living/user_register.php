<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>User Register</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                  <img src="images/couch.png" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <form action="#" method="post" autocomplete="off">
                  <div>
                    <label for="">Name</label>
                    <input type="text" name="name" placeholder="Enter Name" class="form-control" required/>
                  </div>
                  <div class="row">
                      <div class="col-md-6">
                        <label for="">Email</label>
                        <input type="email" name="email" placeholder="Enter Email" class="form-control" required/>
                      </div>
                      <div class="col-md-6">
                        <label for="">Password</label>
                        <input type="password" name="password" placeholder="Enter Password" class="form-control" required/>
                      </div>
                      <div class="col-md-6">
                        <label for="">Contact</label>
                        <input type="number" min="0" name="contact" placeholder="Enter Contact" class="form-control" required/>
                      </div>
                      <div class="col-md-6">
                        <label for="">Address</label>
                        <input type="text" name="address" class="form-control" placeholder="Enter Address" required/>
                      </div>
                      <div class="col-md-6">
                        <label for="">City</label>
                        <input type="text" name="city" class="form-control" placeholder="Enter City" required/>
                      </div>
                      <div class="col-md-6">
                        <label for="">Gender</label><br>
                        <input type="radio" name="gender" value="male" checked/> Male
                        <input type="radio" name="gender" value="female"/> Female
                      </div>
                  </div>

                  <div class="btn-box">
                    <button type="submit" class="send_btn btn btn-primary my-2" name="submit">
                      Register
                    </button>
                  </div>
                </form>
                <p class="text-center my-2">Already have an account?<a href="user_login.php">Login</a></p>      
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?>
<?php
if(isset($_REQUEST["submit"]))
{
  $name = $_REQUEST["name"];
  $email = $_REQUEST["email"];
  $password = $_REQUEST["password"];
  $contact = $_REQUEST["contact"];
  $gender = $_REQUEST["gender"];
  $address = $_REQUEST["address"];
  $city = $_REQUEST["city"];

  include("config.php");
  $q = "INSERT INTO `user`(`name`, `email`, `password`, `gender`, `contact`, `address`, `city`) VALUES ('$name','$email','$password','$gender','$contact','$address','$city')";
  $result = mysqli_query($conn,$q);
  if($result>0)
  {
    //url redirect
    echo "<script>window.location.assign('user_login.php?msg=User Registered Successfully')</script>";
  }
  else 
  {
    //url redirect
    //echo mysqli_error($conn);
    //die();
    echo "<script>window.location.assign('user_register.php?msg=Try Again')</script>";
  }
}
?>
