<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Checkout</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                    <!-- <img src="images/couch.png" class="img-fluid"> -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <table class="table table-bordered table-hover">
					<tr class="table-dark">
						<th>Sno</th>
						<th>Item Name</th>
						<th>Image</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Final Price</th>
					</tr>
						<?php 
							$t =0;
							$total=0;
							if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0) {
							foreach($_SESSION['cart'] as $id=>$quantity){
							$t++;
							include 'config.php';
							$res  = mysqli_query($conn,"select * from product where `id`='$id'");
							if($row=mysqli_fetch_array($res))
							{
						?>
						<tr>
							<td><?php echo $t; ?></td>
							<td><?php echo $row['product_name']; ?></td>
							<td>
								<img class='immanu' src="products/<?php echo $row['image'];?>" style='width:100px; height:100px ; '/></td>
							<td>
								<form action="increase.php">
									<input type="hidden" value="<?php echo $id; ?>" name="id"/>
									<input type="number" style="width:50px" min="1" value="<?php echo $quantity; ?>" name="qty"/>
									<input type="submit" value="update" class="btn btn-sm btn-primary">
								</form>
							</td>
							<td>Rs. <?php echo $row['price']; ?></td>
							<td>
							Rs. <?php $total += ($row['price']*$quantity); echo ($row['price']*$quantity); ?><br>
							<a href='removit.php?x=<?php echo $id; ?>' class="btn btn-primary">remove</a>
							</td>
							<?php
							?>
						</tr>
						<?php
							}
						}
					}
					else
					{
						?>
						<tr>
							<td colspan="6" class="">No Item Found</td>
						</tr>
					<?php
					}
					?>
					<tr>
						<td colspan="5"></td>
						<td>
							<?php
								if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0) {
								echo"<a href='pay.php' class='btn btn-danger l-5 mybtn'>";
								echo "Pay Now";
								echo"</a>";
								}
								else{}
								?>
								<h2 class="">Rs. <?php echo $total; ?></h2>
								<?php
								$_SESSION["total"]=$total;
								?>
						</td>
					</tr>
				</table>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?>
<?php
if(isset($_REQUEST["submit"]))
{
   $email = $_REQUEST["email"];
   $password = $_REQUEST["password"];
   include("config.php");
    $q = "SELECT * from admin_login where email='$email' and password='$password'";
    $result = mysqli_query($conn,$q);
    if($data = mysqli_fetch_array($result))
    {
        //create
        $_SESSION['email']=$email;
        //url redirect
        echo "<script>window.location.assign('dashboard.php')</script>";
    }
    else{
        //url redirect
        echo mysqli_error($conn);
        die();
        echo "<script>window.location.assign('login.php?msg=Invalid email or password')</script>";
   }
}
?>
