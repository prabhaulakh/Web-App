<?php
   include_once("header.php");
   if($_SESSION["email"])
   {
   //store
   $email = $_SESSION["email"];
   }
   else{
   echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
   }
?>
<?php
$id = $_REQUEST["id"];
include("config.php");
$q = "select * from `category` where id='$id'";
$res = mysqli_query($conn,$q);
if($data = mysqli_fetch_array($res))
{
//   print_r($data);
    $t = $data['category_name'];
    $i = $data['logo'];
}
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Update Category</h1>
                </div>
            </div>
          
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <form id="request" class="main_form" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="oldimage" value="<?php echo $i; ?>">
                     <div class="row">
                        <div class="col-md-6">
                           Catgory Name
                           <input class="form-control" placeholder="Category Name" type="text" name="category_name" value="<?php echo $t; ?>"> 
                        </div>
                        <div class="col-md-6">
                           Image
                           <input class="form-control" placeholder="logo" type="file" name="logo"> 
                        </div>
                        <div class="col-md-12">
                           <button type="submit" name="submit" class="btn btn-primary my-3 d-block mx-auto">Submit</button>
                        </div>
                     </div>
                  </form>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html> 

<?php
if(isset($_REQUEST["submit"]))
{
   $category_name = $_REQUEST["category_name"];
   $id = $_REQUEST["id"];
   if($_FILES['logo']['name'])
   {
       $filename = $_FILES["logo"]["name"];
       $filetmpname = $_FILES["logo"]["tmp_name"];
       $newname = rand().$filename;
    
       move_uploaded_file($filetmpname,"category/".$newname);

   }
   else{
    $newname = $_REQUEST['oldimage'];
   }

   include("config.php");

   $q = "UPDATE `category` set `category_name`='$category_name', `logo`='$newname' where id='$id'";

   $result = mysqli_query($conn,$q);
   if($result>0)
    {
        //url redirect
        echo "<script>window.location.assign('manage_category.php?msg=Record Updated')</script>";
    }
    else{
        //url redirect
        // echo mysqli_error($conn);
        // die();
        echo "<script>window.location.assign('manage_category.php?msg=Try Again')</script>";
   }
}
?>