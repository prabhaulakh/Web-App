<?php
   include_once("header.php");
   if($_SESSION["email"])
   {
   //store
   $email = $_SESSION["email"];
   }
   else{
   echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
   }
?>
<?php
$id = $_REQUEST["id"];
include("config.php");
$q = "select * from `product` where id='$id'";
$res = mysqli_query($conn,$q);
if($data = mysqli_fetch_array($res))
{
//   print_r($data);
    $category = $data['category'];
    $product_name = $data['product_name'];
    $quantity = $data['quantity'];
    $price = $data['price'];
    $description = $data['description'];
    $image = $data['image'];
}
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Update Product</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                    <img src="images/couch.png" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                  <form id="request" class="main_form" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                     <input type="hidden" name="oldimage" value="<?php echo $image; ?>">
                     <div class="row">
                        <div class="col-md-6 my-2">
                           Category
                           <select class="form-control" placeholder="category Name" type="text" name="category" required>
                              <option value="" selected disabled>Select category</option>
                              <?php
                                 include("config.php");
                                 $q = "SELECT * from `category`";
                                 $result = mysqli_query($conn,$q);
                                 while($data = mysqli_fetch_array($result)){
                                    // print_r($data);
                                    if($data['id']==$category){
                                       echo "<option value='$data[id]' selected>".$data['category_name']."</option>";
                                    }
                                    else{
                                       echo "<option value='$data[id]'>".$data['category_name']."</option>";
                                    }
                                 }
                              ?>
                           </select> 
                        </div>
                        <div class="col-md-6 my-2">
                           Product Name
                           <input class="form-control" placeholder="Product Name" type="text" name="product_name" value="<?php echo $product_name; ?>" required> 
                        </div>
                        <div class="col-md-3 my-2">
                           Quantity
                           <input class="form-control" placeholder="Quantity" type="number" min="1" name="quantity" value="<?php echo $quantity; ?>" required> 
                        </div>
                        <div class="col-md-3 my-2">
                           Price
                           <input class="form-control" placeholder="Price" type="number" min="0" value="<?php echo $price; ?>"  name="price" required> 
                        </div>
                        <div class="col-md-6 my-2">
                           Image
                           <input class="form-control" placeholder="logo" type="file" name="image" > 
                        </div>
                        <div class="col-md-12 my-2">
                           Description
                           <textarea class="form-control" placeholder="Enter Description" name="description" required><?php echo $description; ?></textarea> 
                        </div>
                        <div class="col-md-12">
                           <button type="submit" name="submit" class="btn btn-primary my-3 d-block mx-auto">Submit</button>
                        </div>
                     </div>
                  </form>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?> 

<?php
if(isset($_REQUEST["submit"]))
{
   $category = $_REQUEST["category"];
   $product_name = $_REQUEST["product_name"];
   $quantity = $_REQUEST["quantity"];
   $description = $_REQUEST["description"];
   $price = $_REQUEST["price"];
   $id = $_REQUEST["id"];
   if($_FILES['image']['name'])
   {
      $filename = $_FILES["image"]["name"];
      $filetmpname = $_FILES["image"]["tmp_name"];
      $newname = rand().$filename;
      move_uploaded_file($filetmpname,"products/".$newname);
   }
   else{
      $newname = $_REQUEST['oldimage'];
   }

   include("config.php");

   $q = "UPDATE `product` SET `category`='$category',`product_name`='$product_name',`quantity`='$quantity',`image`='$newname',`description`='$description',`price`='$price' where id='$id'";

   $result = mysqli_query($conn,$q);
    if($result>0)
    {
        //url redirect
        echo "<script>window.location.assign('manage_product.php?msg=Record Updated')</script>";
    }
    else{
        //url redirect
        echo mysqli_error($conn);
        die();
        echo "<script>window.location.assign('manage_product.php?msg=Try Again')</script>";
   }
}
?>
