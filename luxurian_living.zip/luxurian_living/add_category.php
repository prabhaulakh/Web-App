<?php
   include_once("header.php");
   if($_SESSION["email"])
   {
   //store
   $email = $_SESSION["email"];
   }
   else{
   echo "<script>window.location.assign('login.php?msg=Unauthorised user')</script>";
   }
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Add Category</h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
                    <img src="images/couch.png" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row">
            <div class="col-md-8 col-lg-8 pb-4">
            <?php
                if(isset($_REQUEST["msg"]))
                {
                    echo "<div class='alert alert-info'>".$_REQUEST["msg"]."</div>";
                }
                ?>
                <form id="request" class="main_form" method="post" enctype="multipart/form-data">
                     <div class="row">
                        <div class="col-md-6">
                           Catgory Name
                           <input class="form-control" placeholder="Category Name" type="text" name="category_name"> 
                        </div>
                        <div class="col-md-6">
                           Image
                           <input class="form-control" placeholder="logo" type="file" name="logo"> 
                        </div>
                        <div class="col-md-12">
                           <button type="submit" name="submit" class="btn btn-primary my-3 d-block mx-auto">Submit</button>
                        </div>
                     </div>
                  </form>
            </div>

          </div>

        </div>

      </div>


    </div>
  </div>


<?php
include("footer.php");
?> 

<?php
if(isset($_REQUEST["submit"]))
{
   $category_name = $_REQUEST["category_name"];
   $filename = $_FILES["logo"]["name"];
   $filetmpname = $_FILES["logo"]["tmp_name"];

   $newname = rand().$filename;

   move_uploaded_file($filetmpname,"category/".$newname);

   include("config.php");

   $q = "INSERT INTO `category`(`category_name`, `logo`) VALUES ('$category_name','$newname')";
    $result = mysqli_query($conn,$q);
    if($result>0)
    {
        //url redirect
        echo "<script>window.location.assign('manage_category.php?msg=Record Inserted')</script>";
    }
    else{
        //url redirect
        // echo mysqli_error($conn);
        // die();
        echo "<script>window.location.assign('manage_category.php?msg=Try Again')</script>";
   }
}
?>