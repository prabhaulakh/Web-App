<?php
include("header.php");
?>
<!-- Start Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <div class="intro-excerpt">
                    <h1>Dashboard</h1>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- End Hero Section -->
  	<div class="untree_co-section">
      <div class="container">

        <div class="block">
        <div class="row">
                <div class="col-md-3">
                    <div class="card border-success mb-3" style="max-width: 18rem;">
                        <div class="card-header bg-transparent border-success">Total Category</div>
                        <div class="card-body text-success">
                            <?php
                                include("config.php");
                                $q = "SELECT count(*) FROM `category`";
                                $result = mysqli_query($conn,$q);
                                if($categorycount = mysqli_fetch_array($result))
                                {
                            ?>
                               <p style="font-size:40px;" class="fa fa-star fa-3x"><?php echo $categorycount[0];?></p>
                            <?php 
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-warning mb-3" style="max-width: 18rem;">
                        <div class="card-header bg-transparent border-warning">Total Products</div>
                        <div class="card-body text-warning">
                            <?php
                                include("config.php");
                                $q = "SELECT count(*) FROM `product`";
                                $result = mysqli_query($conn,$q);
                                if($productcount = mysqli_fetch_array($result))
                                {
                            ?>
                               <p style="font-size:40px;" class="fa fa-product-hunt fa-3x"><?php echo $productcount[0];?></p>
                            <?php 
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6"></div>
                <div class="col-md-3">
                    <div class="card border-primary mb-3" style="max-width: 18rem;">
                        <div class="card-header bg-transparent border-primary">Total Users</div>
                        <div class="card-body text-primary">
                            <?php
                                include("config.php");
                                $q = "SELECT count(*) FROM `user`";
                                $result = mysqli_query($conn,$q);
                                if($usercount = mysqli_fetch_array($result))
                                {
                            ?>
                               <p style="font-size:40px;" class="fa fa-user fa-3x"><?php echo $usercount[0];?></p>
                            <?php 
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-dark mb-3" style="max-width: 18rem;">
                        <div class="card-header bg-transparent border-dark">Total Orders</div>
                        <div class="card-body text-dark">
                            <?php
                                include("config.php");
                                $q = "SELECT count(*) FROM `orders`";
                                $result = mysqli_query($conn,$q);
                                if($ordercount = mysqli_fetch_array($result))
                                {
                            ?>
                               <p style="font-size:40px;" class="fa fa-list fa-3x"><?php echo $ordercount[0];?></p>
                            <?php 
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>

      </div>


    </div>
  </div>


<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>